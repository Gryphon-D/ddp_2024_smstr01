import streamlit as st


with st.sidebar:
    col1, col2 = st.columns([2, 3])

    with col1:
        st.image("fitnes.jpeg",)

    with col2:
        st.header("OLAHRAGA")
tombol = st.sidebar.selectbox("Pilih fitur yang ingin dijalankan:", ["Dashboard","Sprint", "Swimming", "Archery Score",
                                                                 "Shot put"])

if tombol == "Dashboard":
    st.title("tim pengembang kece!")

if tombol == "Dashboard":

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.image("ihlal.jpg", width=150)
        st.write("Ihlal")
    with col2:
        st.image("me.jpg", width=150)
        st.write("Gryphon")
    with col3:
        st.image("aul.png", width=150)
        st.write("Aulia")
    with col4:
        st.image("tri.jpg", width=150)
        st.write("Trinita")
        
    
    st.markdown(
    """
    <div style="text-align: center;">
        <p style="font-size:20px; font-weight: bold; margin-top: 20px;">
            DESKRIPSI
        </p>
    </div>
    """,
    unsafe_allow_html=True
)
        
    st.write("""
             Dengan sistem ini kami membantu untuk mengetahui hasil  dari beberapa cabang olahraga dengan standar 
             nasional yang terbukti dapat menghitung hasil pertandingan dengan akurat dan adil.              
             """)
    st.write("""
             Fitur-fitur yang kami sediakan adalah:  
             """)
    st.write("""1. gryphon dayfullah(Sprint) : Diladalam fitur yang di buat oleh gryphon ini menghitung Kecepatan
             Lari dengan standar internasional """)
    st.write("""
             2. Muhamad Ihlal (Swimming) : Dalam fitur ini menghitung kalori yang terbakar saat berenang dengan gaya yang 4 Gaya yang berbeda. 
             """)
    st.write("""
            3. Trinita Aguistin(Archery) : Dalam fitur ini menghitung skor panahan dari hasil keseluruhan ronde.
             """)
    st.write("""
            4. Aulia Rea Sagita (Shot put) : Dalam fitur ini menghitung hasil percobaan Tolak Peluru dari 2 atlet atau lebih dan mengetahui pemenang.
             """)


if tombol == "Sprint":
        class PelariSprint:
            def __init__(self, jarak, waktu):
                if waktu <= 0:
                    raise ValueError("Waktu harus lebih besar dari 0 detik.")
                self.jarak = jarak
                self.waktu = waktu

            def hitung_kecepatan(self):
                return self.jarak / self.waktu

        def main():
            with open("lar.gif", "rb") as file:
                gif_data = file.read()
            st.image(gif_data)
            st.header("hitung kecepatan pelari")

            try:
                jarak = st.slider("Masukkan jarak yang ditempuh (meter):", 0, 100)
                waktu = st.number_input("Masukkan waktu yang diperlukan (detik):", min_value=0.0, format="%.2f")

                if st.button("hitung kecepatan") :
                    if jarak > 0 and waktu > 0:
                        pelari = PelariSprint(jarak, waktu)
                        kecepatan = pelari.hitung_kecepatan()
                        st.success(f"Kecepatan pelari adalah {kecepatan:.2f} meter per detik (m/s).")
                    else:
                        st.error("Masukkan nilai jarak dan waktu yang valid.")
            except ValueError as salah:
                st.error(f"Input tidak valid: {salah}")

        if PelariSprint == PelariSprint:
            main()



elif tombol == "Swimming":
    st.header("Hitung Kalori Renang")
    with open("kolam.gif", "rb") as file:
        gif_data = file.read()
    st.image(gif_data)

    def hitung_kalori(gaya, durasi, berat_badan):
        gaya = gaya.lower()
        if gaya == "bebas":
            met = 7.0
        elif gaya == "dada":
            met = 5.0
        elif gaya == "punggung":
            met = 5.5
        elif gaya == "kupu-kupu":
            met = 8.0
        else:
            return "Gaya Renang Tidak Valid"

        kalori_per_menit = met * berat_badan * (1 / 60)
        kalori_total = kalori_per_menit * durasi
        return kalori_total

    berat_badan = st.number_input("Masukkan Berat Badan Anda (kg):", min_value=0.0, step=0.1)
    gaya = st.selectbox("Pilih Gaya Renang:", ["Bebas", "Dada", "Punggung", "Kupu-kupu"])
    durasi = st.number_input("Masukkan Durasi Renang (menit):", min_value=0.0, step=0.1)

    if st.button("Hitung Kalori"):
        if berat_badan > 0 and durasi > 0:
            kalori = hitung_kalori(gaya, durasi, berat_badan)
            if isinstance(kalori, str):
                st.error(kalori)
            else:
                st.success(f"Kalori yang terbakar adalah {kalori:.2f} kalori.")
        else:
            st.error("Berat badan dan durasi harus lebih besar dari 0.")

elif tombol == "Archery Score":
    st.header("Hitung skor panahan")
    with open("panah.gif", "rb") as file:
     gif_data = file.read()
     st.image(gif_data)

    def hitung_skor(jumlah_ronde, anak_per_ronde, skor_per_ronde):
        total_skor = 0
        tabel_skor = []
        for i in range(jumlah_ronde):
            ronde_skor = sum(skor_per_ronde[i])
            total_skor += ronde_skor
            tabel_skor.append({"Ronde": i + 1, "Skor Anak Panah": skor_per_ronde[i], "Total Ronde": ronde_skor})
        return total_skor, tabel_skor

    jumlah_ronde = st.number_input("Masukkan jumlah ronde:", min_value=1, step=1, value=1)

    anak_per_ronde = st.number_input("Masukkan jumlah anak panah per ronde:", min_value=1, step=1, value=1)

    skor_per_ronde = []
    for i in range(jumlah_ronde):
        st.subheader(f"Ronde {i + 1}")
        skor_ronde = []
        for j in range(anak_per_ronde):
            skor = st.number_input(
                f"  Skor anak panah ke-{j + 1} (Ronde {i + 1}):",
                min_value=0,
                max_value=10,
                step=1,
                value=0,
                key=f"ronde_{i}panah{j}",
            )
            skor_ronde.append(skor)
        skor_per_ronde.append(skor_ronde)

    if st.button("Hitung"):
        total_skor, tabel_skor = hitung_skor(jumlah_ronde, anak_per_ronde, skor_per_ronde)
        
        st.subheader("Tabel Skor Panahan")
        
        tabel_data = [["Ronde", "Skor Anak Panah", "Total Ronde"]]
        for data in tabel_skor:
            tabel_data.append([data["Ronde"], data["Skor Anak Panah"], data["Total Ronde"]])

        st.table(tabel_data)

        st.success(f"Total Skor Anda adalah: {total_skor}")

elif tombol == "Shot put":
    st.header("Hitung Hasil Tolak Peluru")
    with open("tolak.gif", "rb") as file:
        gif_data = file.read()
    st.image(gif_data)

    jumlah_atlet = st.number_input("Masukkan jumlah atlet:", min_value=1, step=1)

    if jumlah_atlet > 0:
        atlet_data = {}
        
        for i in range(1, jumlah_atlet + 1):
            st.subheader(f"Data Atlet {i}")
            nama = st.text_input(f"Masukkan nama atlet {i}:", key=f"nama_atlet_{i}")
            percobaan = st.number_input(f"Berapa kali {nama} melakukan percobaan?", min_value=1, step=1, key=f"percobaan_{i}")
            
            jarak = []
            for j in range(1, percobaan + 1):
                hasil = st.number_input(
                    f"Hasil percobaan ke-{j} (meter) untuk {nama}:",
                    min_value=0.0,
                    step=0.1,
                    key=f"percobaan_{i}_{j}"
                )
                jarak.append(hasil)

            if nama:
                atlet_data[nama] = jarak

        if st.button("Hitung"):
            if atlet_data:
                pemenang = None
                jarak_terjauh = 0
                hasil_akhir = []

                for nama, hasil in atlet_data.items():
                    terbaik = max(hasil)
                    rata_rata = sum(hasil) / len(hasil)
                    hasil_akhir.append(
                        f"Atlet: {nama} | Jarak terbaik: {terbaik:.2f} meter | Rata-rata: {rata_rata:.2f} meter"
                    )
                    
                    if terbaik > jarak_terjauh:
                        jarak_terjauh = terbaik
                        pemenang = nama

                st.subheader("Hasil Akhir")
                for hasil in hasil_akhir:
                    st.write(hasil)
                
                st.success(f"Pemenang adalah {pemenang} dengan jarak {jarak_terjauh:.2f} meter!")
            else:
                st.error("Data atlet belum lengkap.")


